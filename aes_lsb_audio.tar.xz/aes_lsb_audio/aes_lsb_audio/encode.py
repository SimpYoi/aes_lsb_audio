import wave
import sys

def encode_lsb(input_audio, output_audio, data_bytes):
    audio = wave.open(input_audio, "rb")
    frame_bytes = bytearray(audio.readframes(audio.getnframes()))

    bits = ''.join(format(byte, '08b') for byte in data_bytes)
    bits += '00000011' * 3  

    if len(bits) > len(frame_bytes):
        raise ValueError("Data too large to embed in audio.")

    for i in range(len(bits)):
        frame_bytes[i] = (frame_bytes[i] & 254) | int(bits[i])

    modified_audio = wave.open(output_audio, "wb")
    modified_audio.setparams(audio.getparams())
    modified_audio.writeframes(bytes(frame_bytes))
    audio.close()
    modified_audio.close()

    print(f"Data embedded in {output_audio}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 encode.py <original.wav>")
        sys.exit(1)

    with open("message_compressed.bin", "rb") as f:
        data = f.read()

    encode_lsb(sys.argv[1], "stego_audio.wav", data)
