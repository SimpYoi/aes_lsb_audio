import wave
import zlib
from cryptography.fernet import Fernet

def load_key():
    return open("secret.key", "rb").read()

def extract_lsb(stego_audio):
    audio = wave.open(stego_audio, "rb")
    frame_bytes = bytearray(audio.readframes(audio.getnframes()))
    extracted_bits = [str(byte & 1) for byte in frame_bytes]
    audio.close()

    byte_str = ''.join(extracted_bits)
    data_bytes = bytearray()
    for i in range(0, len(byte_str), 8):
        byte = byte_str[i:i+8]
        if byte == '00000011':
            if byte_str[i:i+24] == '00000011' * 3:
                break
        data_bytes.append(int(byte, 2))
    return bytes(data_bytes)

def decompress_and_decrypt(data: bytes, key: bytes) -> str:
    f = Fernet(key)
    decrypted = f.decrypt(zlib.decompress(data))
    return decrypted.decode()

if __name__ == "__main__":
    try:
        data = extract_lsb("stego_audio.wav")
        key = load_key()
        message = decompress_and_decrypt(data, key)

        with open("decoded_mess.txt", "w", encoding="utf-8") as f:
            f.write(message)

        print("Hidden message saved to decoded_mess.txt")
    except Exception as e:
        print(f"Error: {e}")
