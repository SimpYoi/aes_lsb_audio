import zlib
from cryptography.fernet import Fernet
import sys

def load_key():
    with open("secret.key", "rb") as key_file:
        return key_file.read()

def encrypt_message(message: str, key: bytes) -> bytes:
    f = Fernet(key)
    return f.encrypt(message.encode())

def compress_data(data: bytes) -> bytes:
    return zlib.compress(data)

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python3 compress.py <message.txt>")
        sys.exit(1)

    try:
        with open(sys.argv[1], "r", encoding="utf-8") as f:
            message = f.read().strip()

        key = load_key()
        encrypted = encrypt_message(message, key)
        compressed = compress_data(encrypted)

        with open("message_compressed.bin", "wb") as out:
            out.write(compressed)

        print("Compressed and encrypted message saved to message_compressed.bin")
    except Exception as e:
        print(f"Error: {e}")
